"""Validation modules for document structure and references."""
