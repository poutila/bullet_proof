"""Compliance checking modules for CLAUDE.md standards."""
