"""Project analysis tools for documentation and structure verification."""
